"""Separate trajectory accuracy from long-run single-member state statistics."""

import numpy as np
from scipy.stats import wasserstein_distance


def sanitize_forecasts(forecast, scale, physical_size):
    """Censor at the first nonfinite/extreme prediction; never hide failures."""
    result = np.asarray(forecast).copy()
    normalized = result[:, :, :physical_size] / scale[:physical_size]
    invalid = ~np.isfinite(normalized).all(axis=2) | (
        np.abs(normalized).max(axis=2) > 1e6
    )
    failed = np.maximum.accumulate(invalid, axis=1)
    result[failed] = np.nan
    return result


def coherence_curves(truth, forecast, scale):
    """Prefix thresholds with a training-only scale fixed across forecast lengths."""
    n = np.arange(1, truth.shape[1] + 1)[None, :, None]
    actual = truth
    predicted = np.nan_to_num(forecast, nan=0, posinf=0, neginf=0)
    a, b = np.cumsum(actual, axis=1), np.cumsum(predicted, axis=1)
    aa, bb = np.cumsum(actual**2, axis=1), np.cumsum(predicted**2, axis=1)
    ab = np.cumsum(actual * predicted, axis=1)
    va, vb = np.maximum(aa - a * a / n, 0), np.maximum(bb - b * b / n, 0)
    denominator = np.sqrt(va * vb)
    correlation = np.divide(
        ab - a * b / n, denominator, out=np.zeros_like(ab), where=denominator > 1e-12
    )
    correlation = np.clip(correlation, -1, 1)
    rmse = np.sqrt(np.cumsum((actual - predicted) ** 2, axis=1) / n) / scale
    failures = (correlation < 0.8) | (rmse > 0.5) | ~np.isfinite(forecast)
    failures[:, 0] = False
    failed = np.maximum.accumulate(failures, axis=1)
    lengths = np.argmax(failed, axis=1) + 1
    censored = ~failed[:, -1]
    lengths[censored] = truth.shape[1]
    return lengths, censored, (~failed).mean(axis=0), rmse


def evaluate_long_run(truth, members, scale, physical_size, dt, cutoffs):
    """Report ensemble point errors and individual-trajectory distribution errors."""
    members = np.asarray([sanitize_forecasts(m, scale, physical_size) for m in members])
    mean = members.mean(0)
    actual = truth[:, :, :physical_size]
    predicted = mean[:, :, :physical_size]
    lengths, censored, survival, prefix = coherence_curves(
        actual, predicted, scale[:physical_size]
    )
    valid = np.isfinite(predicted).all(axis=2)
    numeric_failure = ~valid
    first_numeric = np.argmax(numeric_failure, axis=1) + 1
    first_numeric[~numeric_failure.any(axis=1)] = 0
    errors = predicted - actual
    metrics = {
        "coherence_definition": (
            "First lead >=2 with prefix correlation<0.8 or prefix "
            "RMSE/training_std>0.5; training scale is fixed across "
            "horizons."
        ),
        "coherence_time_by_origin_state": (lengths * dt).tolist(),
        "coherence_censored_by_origin_state": censored.tolist(),
        "coherence_x_median_capped": float(np.median(lengths[:, 0]) * dt),
        "coherence_x_mean_capped": float(np.mean(lengths[:, 0]) * dt),
        "coherence_x_censored_fraction": float(censored[:, 0].mean()),
        "numerical_failure_fraction": float(numeric_failure.any(axis=1).mean()),
        "numerical_failure_lead_by_origin": first_numeric.tolist(),
        "point_by_cutoff": {},
    }
    for cutoff in cutoffs:
        lead = min(int(round(cutoff / dt)), truth.shape[1])
        partial = errors[:, :lead]
        if np.isfinite(partial).all():
            rmse = np.sqrt(np.mean(partial**2, axis=(0, 1))).tolist()
            normalized = float(np.sqrt(np.mean((partial / scale[:physical_size]) ** 2)))
        else:
            rmse, normalized = None, None
        metrics["point_by_cutoff"][str(cutoff)] = {
            "rmse_by_state": rmse,
            "normalized_rmse_all_states": normalized,
            "valid_origin_fraction": float(valid[:, :lead].all(axis=1).mean()),
        }
    tail = truth.shape[1] // 10
    actual_tail = actual[:, tail:].reshape(-1, physical_size)
    climate = []
    for member in members:
        sample = member[:, tail:, :physical_size].reshape(-1, physical_size)
        finite = np.isfinite(sample).all(axis=1)
        if finite.all():
            w = [
                wasserstein_distance(actual_tail[:, i], sample[:, i]) / scale[i]
                for i in range(physical_size)
            ]
            std_ratio = (sample.std(0) / actual_tail.std(0)).tolist()
            mean_bias = (
                (sample.mean(0) - actual_tail.mean(0)) / scale[:physical_size]
            ).tolist()
        else:
            w, std_ratio, mean_bias = None, None, None
        climate.append(
            {
                "normalized_wasserstein_by_state": w,
                "std_ratio_by_state": std_ratio,
                "normalized_mean_bias_by_state": mean_bias,
                "finite_fraction": float(finite.mean()),
            }
        )
    scores = [
        np.mean(c["normalized_wasserstein_by_state"])
        for c in climate
        if c["normalized_wasserstein_by_state"] is not None
    ]
    metrics["individual_member_climate"] = climate
    metrics["climate_valid_member_fraction"] = len(scores) / len(members)
    metrics["mean_normalized_member_wasserstein"] = (
        float(np.mean(scores)) if len(scores) == len(members) else None
    )
    metrics["climate_tail_start_time"] = tail * dt
    metrics["climate_note"] = (
        "Distribution statistics use individual free trajectories, "
        "not the ensemble mean; first 10% of forecast excluded. "
        "Distribution agreement alone does not establish correct "
        "dynamics."
    )
    # Plot arrays retain explicit NaNs for numerical failures.
    point_rmse = np.sqrt(np.mean(errors**2, axis=0))
    return metrics, {
        "members": members,
        "mean": mean,
        "point_rmse_by_lead": point_rmse,
        "coherence_survival": survival,
        "prefix_nrmse_mean": prefix.mean(axis=0),
    }
