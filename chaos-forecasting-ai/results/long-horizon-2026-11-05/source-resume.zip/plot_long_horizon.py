"""Truth overlays, coherence retention, and long-run single-member diagnostics."""

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

COLORS = ["#76d2c4", "#80b6ed", "#ff8b78", "#f6ca67", "#b9a0f0", "#9fdb88"]


def autocorrelation(values, maximum_lag):
    """Pool within-trajectory lag pairs without crossing trajectory boundaries."""
    centered = values - values.mean(axis=1, keepdims=True)
    result = []
    for lag in range(maximum_lag + 1):
        a = centered if lag == 0 else centered[:, :-lag]
        b = centered if lag == 0 else centered[:, lag:]
        denominator = np.sqrt(np.sum(a * a) * np.sum(b * b))
        result.append(float(np.sum(a * b) / denominator) if denominator > 0 else 0)
    return np.asarray(result)


def plot_system(out):
    out = Path(out)
    config = json.loads((out / "config.json").read_text())
    metrics = json.loads((out / "metrics.json").read_text())
    data = np.load(out / "data.npz")
    actual = data["truth"]
    dt, d = config["dt"], config["physical_size"]
    scale = data["train"].reshape(-1, data["train"].shape[-1]).std(0)[:d]
    lead = np.arange(1, actual.shape[1] + 1) * dt
    names = list(metrics)
    forecasts = {
        name: np.load(out / (name.lower().replace(" ", "-") + ".npz")) for name in names
    }
    figures = out / "figures"
    figures.mkdir(exist_ok=True)
    plt.style.use("dark_background")
    system = out.name

    def save(figure, name):
        figure.savefig(figures / f"{name}.png", dpi=150)
        figure.savefig(figures / f"{name}.pdf")
        plt.close(figure)

    def overlays(maximum, filename):
        figure, axes = plt.subplots(
            len(names), d, figsize=(6 * d, 2.7 * len(names)), squeeze=False
        )
        for row, (name, color) in enumerate(zip(names, COLORS, strict=True)):
            saved = forecasts[name]
            for state in range(d):
                axis = axes[row, state]
                axis.plot(
                    lead,
                    actual[0, :, state],
                    color="white",
                    linewidth=1.4,
                    label="Truth",
                )
                for member in saved["members"]:
                    axis.plot(
                        lead,
                        member[0, :, state],
                        color=color,
                        alpha=0.23,
                        linewidth=0.7,
                    )
                axis.plot(
                    lead,
                    saved["mean"][0, :, state],
                    color=color,
                    linewidth=1,
                    label="Forecast mean",
                )
                coherence = metrics[name]["coherence_time_by_origin_state"][0][state]
                censored = metrics[name]["coherence_censored_by_origin_state"][0][state]
                if not censored:
                    axis.axvline(coherence, color=color, linestyle="--", linewidth=0.8)
                qualifier = ">=" if censored else "="
                axis.set(
                    title=(
                        f"{name} | {config['labels'][state]} | "
                        f"L {qualifier} {coherence:.2f}"
                    ),
                    xlabel="Time since last observation",
                    ylabel=config["labels"][state],
                    xlim=(0, maximum),
                )
                low, high = np.min(actual[:, :, state]), np.max(actual[:, :, state])
                margin = 0.25 * (high - low)
                axis.set_ylim(low - margin, high + margin)
                selection = lead <= maximum
                values = saved["mean"][0, selection, state]
                offscale = (
                    (~np.isfinite(values))
                    | (values < low - margin)
                    | (values > high + margin)
                )
                if offscale.any():
                    axis.text(
                        0.02,
                        0.87,
                        f"{offscale.mean():.0%} off-scale/invalid",
                        transform=axis.transAxes,
                        fontsize=8,
                        color="#ff8b78",
                    )
                axis.legend(fontsize=7, loc="upper right")
                axis.grid(alpha=0.15)
        figure.suptitle(
            f"{system}: free forecast vs truth | reference origin", fontsize=15
        )
        figure.text(
            0.03,
            0.01,
            "Thin colored lines: individual neural members; bold: mean. "
            "L uses fixed training-standard-deviation thresholds.\n"
            "No truth updates after the initial context. Axes show truth range ±25%; "
            "off-scale and invalid values remain counted in metrics.",
            fontsize=9,
        )
        figure.tight_layout(rect=(0, 0.045, 1, 0.97))
        save(figure, filename)

    overlays(180 * dt, "early-overlays")
    overlays(lead[-1], "long-overlays")
    figure, axes = plt.subplots(2, 1, figsize=(12, 8), sharex=True)
    for name, color in zip(names, COLORS, strict=True):
        values = forecasts[name]
        # Physical-state point RMSE normalized by training scales, across test origins.
        error = (values["mean"][:, :, :d] - actual[:, :, :d]) / scale
        rmse = np.sqrt(np.mean(error**2, axis=(0, 2)))
        axes[0].plot(lead, rmse, label=name, color=color)
        axes[1].plot(lead, values["coherence_survival"][:, 0], label=name, color=color)
    axes[0].set(ylabel="Normalized point RMSE")
    axes[0].set_yscale("symlog", linthresh=0.1)
    axes[1].set(
        ylabel="Fraction retaining x coherence",
        xlabel="Forecast lead (time units)",
        ylim=(-0.02, 1.02),
    )
    for axis in axes:
        axis.legend(fontsize=8, ncol=3)
        axis.grid(alpha=0.2)
    figure.suptitle(f"{system}: accuracy and coherence across nine dependent origins")
    figure.tight_layout()
    save(figure, "error-and-coherence")
    tail = actual.shape[1] // 10
    truth_tail = actual[:, tail:, :d]
    phase_y = 1 if d == 2 else 2
    figure, axes = plt.subplots(len(names), 3, figsize=(16, 3 * len(names)))
    max_lag = min(int(20 / dt), truth_tail.shape[1] // 4)
    lags = np.arange(max_lag + 1) * dt
    actual_acf = autocorrelation(truth_tail[:, :, 0], max_lag)
    flattened = truth_tail.reshape(-1, d)
    limits = [
        (flattened[:, i].min() - 0.1 * scale[i], flattened[:, i].max() + 0.1 * scale[i])
        for i in range(d)
    ]
    bins = np.linspace(*limits[0], 61)
    actual_counts, _ = np.histogram(flattened[:, 0], bins=bins)
    for row, (name, color) in enumerate(zip(names, COLORS, strict=True)):
        members = forecasts[name]["members"][:, :, tail:, :d]
        # Phase portraits show a single free trajectory, never the ensemble average.
        first = members[0, 0]
        axes[row, 0].plot(
            truth_tail[0, :, 0],
            truth_tail[0, :, phase_y],
            color="white",
            alpha=0.55,
            linewidth=0.7,
            label="Truth",
        )
        axes[row, 0].plot(
            first[:, 0],
            first[:, phase_y],
            color=color,
            alpha=0.8,
            linewidth=0.7,
            label="One member",
        )
        axes[row, 0].set(
            xlim=limits[0],
            ylim=limits[phase_y],
            xlabel=config["labels"][0],
            ylabel=config["labels"][phase_y],
            title=name + " | state projection",
        )
        axes[row, 1].stairs(
            actual_counts / (len(flattened) * np.diff(bins)),
            bins,
            color="white",
            label="Truth",
        )
        for member in members:
            sample = member.reshape(-1, d)
            finite = np.isfinite(sample).all(axis=1)
            counts, _ = np.histogram(sample[finite, 0], bins=bins)
            axes[row, 1].stairs(
                counts / (len(sample) * np.diff(bins)), bins, color=color, alpha=0.6
            )
            if finite.all():
                acf = autocorrelation(member[:, :, 0], max_lag)
                axes[row, 2].plot(lags, acf, color=color, alpha=0.65)
        axes[row, 2].plot(lags, actual_acf, color="white", label="Truth")
        axes[row, 1].set(
            xlabel=config["labels"][0],
            ylabel="Probability density",
            title="Individual-member distribution",
        )
        axes[row, 2].set(
            xlabel="Lag (time units)",
            ylabel="Autocorrelation",
            ylim=(-1.05, 1.05),
            title="Within-trajectory correlation",
        )
        for axis in axes[row]:
            axis.grid(alpha=0.15)
        axes[row, 0].legend(fontsize=7)
    figure.suptitle(f"{system}: behavior after point forecasts diverge", fontsize=15)
    figure.text(
        0.03,
        0.01,
        "First 10% of each forecast omitted. State projections show the "
        "reference trajectory; densities and correlations pool nine origins within "
        "each member.\nNeural ensemble means are excluded from these distribution "
        "diagnostics. Display limits use truth ranges; no histogram renormalization "
        "after excluding off-scale samples.",
        fontsize=9,
    )
    figure.tight_layout(rect=(0, 0.045, 1, 0.97))
    save(figure, "long-run-behavior")
    # A compact comparison is easier to open than the full all-variable grid.
    figure, axes = plt.subplots(3, 1, figsize=(14, 9), sharex=True)
    for axis, name in zip(axes, ["Transformer", "GRU", "MLP"], strict=True):
        saved = forecasts[name]
        axis.plot(lead, actual[0, :, 0], color="white", linewidth=1, label="Truth")
        for i, member in enumerate(saved["members"]):
            axis.plot(
                lead,
                member[0, :, 0],
                linewidth=0.8,
                alpha=0.65,
                label=f"Seed member {i + 1}",
            )
        axis.plot(
            lead,
            saved["mean"][0, :, 0],
            color="gold",
            linewidth=1.3,
            label="Ensemble mean",
        )
        axis.set(title=name, ylabel=config["labels"][0])
        axis.grid(alpha=0.15)
        axis.legend(fontsize=7, ncol=5)
    axes[-1].set_xlabel("Forecast lead (time units)")
    figure.suptitle(f"{system}: individual free trajectories and their mean")
    figure.tight_layout()
    save(figure, "neural-members")
    print(f"{system}: plots saved to {figures}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    args = parser.parse_args()
    plot_system(args.results)
